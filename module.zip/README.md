# Dwarves in a Sack
Have you ever wanted to put your annoying dwarf friend in a sack? Maybe roast them over a fire or squash them into jelly? This module allows you to do so. You can now put any actor into a container.

Simply drag and drop an actor on which you have at least limited permissions from the actor tab to the container. 
![image](https://github.com/user-attachments/assets/36e3d6ad-3565-41d9-a6d4-c7a9d03b3bb6)
Weight is automatically calculated by the weight of the actor and the weight of all their items.

## Required permissions
Players need the following permissions to allow this module to function
![image](https://github.com/user-attachments/assets/2616b97f-a6d1-48e0-bb58-9e195890a336)

## Systems
Currently works on
- DnD5e

I am planning on eventually supporting
- PF1
- PF2
