export const constants = {
    MODULEID: "dwarves-in-a-sack",
    DEBUG: "[Dwarves in a Sack] DEBUG | "
}